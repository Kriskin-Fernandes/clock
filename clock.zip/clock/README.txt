the clock displays in the format DAY, dd mm yy, hh mm ss

there is a text box below the time, here is where you can execute commands
typing a "#" followed by a hex color code changes the background to that color
typing a "!" changes all text after it to morse code, where each letter is read top-to-bottom
typing a "?" scrambles the date, day and time and generates a random 7 digit number
typing $123$ starts a countdown for 123 seconds, can be used with any number
typing musical notes (A-G) and then % at the end plays the notes. you can combine notes inside brackets eg(ABC)
typing a frequency in Hz and then % plays the frequency until the % is deleted
typing a "/" opens the downloads directory